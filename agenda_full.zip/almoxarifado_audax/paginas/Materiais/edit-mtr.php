<?php

$id = $_GET["id"];


$sql = "SELECT * FROM materiais WHERE id= {$id}";

$rs = mysqli_query($conexao,$sql) or die("Erro ao recuperar os dados! " . mysqli_error($conexao));

$dados = mysqli_fetch_assoc($rs)
?>

<header>
    <h3>
        Editar Materiais 
    </h3>
</header>

<div>
    <form action="index.php?menuop=update-mtr" method="post">


    <div>
        <label for="id"> Id </label>
        <input type="text" name="Id" value="<?=$dados["id"]?>">
    </div>

    <div>
        <label for="Material"> Materiais </label>
        <input type="text" name="Material" value="<?=$dados["Material"]?>">
    </div>


    <div>
        <input type="submit" value="Atualizar" name="bntAtualizar">
    </div>

    </form>
</div>




