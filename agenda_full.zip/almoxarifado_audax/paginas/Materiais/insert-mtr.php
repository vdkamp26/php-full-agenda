<header>
    <h3>Inserir Material</h3>
</header>
<?php

    $Material = mysqli_real_escape_string($conexao,$_POST["Material"]); 
 
    $sql = "INSERT INTO materiais (Material) VALUES('{$Material}')"; 
    $rs = mysqli_query($conexao,$sql) or die("Erro ao executar a consulta! " . mysqli_error($conexao));

    echo "O registro foi inserido com sucesso! "


?>