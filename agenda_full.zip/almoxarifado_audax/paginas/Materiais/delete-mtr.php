<header>
    <h3>Deletar Materiais</h3>
</header>


<?php

$id = mysqli_real_escape_string($conexao,$_GET["id"]);
$sql = " DELETE FROM materiais WHERE id= '{$id}' ";

mysqli_query($conexao,$sql) or die("Erro ao excluir o registro.!!!! " . mysqli_error($conexao));

echo "Registro excluído com sucesso. ";



?>