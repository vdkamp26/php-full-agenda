<header>
    <h3>Cadastrar Materiais</h3>
</header>

<div>
    <a  class="btn btn-primary" href="index.php?menuop=cad-mtr">+ Novo Material</a>
</div>




<table class="table table-light table-hover table-bordered">

    <thead>

        <tr>
            
           <th>Nº</th>
           <th>Tipo de Material</th>
           <th>Editar</th>
           <th>Deletar</th>
              
        </tr>

    </thead>
    <tbody>
        <?php



          $txt_pesquisa2 = (isset($_POST["txt_pesquisa2"]))?$_POST["txt_pesquisa2"]:"";
          
          $sql = "SELECT id, upper(Material) AS Material, FROM materiais ";

          $sql = "SELECT * FROM materiais";
          
          $rs = mysqli_query($conexao,$sql) or die("Erro ao execultar a consulta. " . mysqli_error($conexao));
          while($dados = mysqli_fetch_assoc($rs)) {

         
            ?>
        <tr>
        <td> <?=$dados["id"]?> </td>
        <td> <?=$dados["Material"]?> </td>
        <td class="text-center"> <a href="index.php?menuop=edit-mtr&id=<?=$dados["id"] ?> "?><i class="bi bi-gear bi center"></i></a></td>
        <td class="text-center"> <a href="index.php?menuop=delete-mtr&id=<?=$dados["id"] ?> "?><i class="bi bi-trash"></i></a></td>
        </tr>

        <?php
          }
          ?>
    </tbody>

</table>
<br>

