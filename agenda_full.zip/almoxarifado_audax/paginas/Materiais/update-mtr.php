<header>
    <h3>Atualizar Materiais</h3>
</header>
<?php

    $Id = mysqli_real_escape_string($conexao,$_POST["Id"]); 
    $Material = mysqli_real_escape_string($conexao,$_POST["Material"]); 

    $sql = "UPDATE materiais SET Material = '{$Material}' WHERE id= '{$Id}' "; 
    $rs = mysqli_query($conexao,$sql) or die("Erro ao executar a consulta! " . mysqli_error($conexao));

    echo "O registro foi atualizado com sucesso! "


?>