<header>

    <h3>Cadastro de Materiais</h3>

</header>


<div>
    <form action="index.php?menuop=insert-mtr" method="post">

    
    <div>
        <label for="Material">Material</label>
        <input type="text" name="Material">
    </div>

        <div>
        <input type="submit" value="Adicionar" name="btnAdicionar2">
        </div>

    </form>
</div>