<header>
    <h3>Página inicial</h3>



    <div>
<a class="btn btn-outline-primary btn-sm mb-2" href="index.php?menuop=usuarios"><i class="bi bi-person">    </i>  Usuarios</a>  
</div>




<div>
<a class="btn btn-outline-primary btn-sm" href="index.php?menuop=materiais"><i class="bi bi-ui-radios-grid">    </i> Materiais</a> 
</div>




