<header>

    <h3>Cadastro de Usuário</h3>

</header>


<div>
    <form action="index.php?menuop=insert-user" method="post">

    <div>
        <label for="nome">Usuario</label>
        <input type="text" name="Nome">
    </div>

    <div>
        <label for="email">E-mail</label>
        <input type="email" name="Email">
    </div>

    <div>
        <label for="funcao">Função</label>
        <input type="text" name="Funcao">
    </div>

        <div>
        <input type="submit" value="Adicionar" name="btnAdicionar">
        </div>

    </form>
</div>