<header>
    <h3>Inserir Usuário</h3>
</header>
<?php

    $Nome = mysqli_real_escape_string($conexao,$_POST["Nome"]); 
    $Email = mysqli_real_escape_string($conexao,$_POST["Email"]);
    $Funcao = mysqli_real_escape_string($conexao,$_POST["Funcao"]);   

    $sql = "INSERT INTO usuarios (Nome, Email, Funcao) VALUES('{$Nome}','{$Email}','{$Funcao}')"; 
    $rs = mysqli_query($conexao,$sql) or die("Erro ao executar a consulta! " . mysqli_error($conexao));

    echo "O registro foi inserido com sucesso! "


?>