<header>
    <h1>Usuários</h1>
</header>

<div>
<a class="btn btn-primary mb-2" href="index.php?menuop=cad-user">+ Novo Usuário</a>

</div>

<div>
    <form action="index.php?menuop=user" method="post">

    <input  type="text" name="txt_pesquisa">
    

    <button class="btn btn-outline-primary btn-sm" type="submit"><i class="bi bi-search"> Pesquisar</i></button>

    </form>
    
</div>

<div class="tabela">
<table class="table table-light table-hover table-bordered table-sm">

    <thead>

        <tr>
            <th>Nº</th>
           <th>Nome</th>
           <th>E-mail</th>
           <th>Função</th> 
           <th>Ações</th>
           <th>Deletar</th>  
        </tr>

    </thead>
    <tbody>
        <?php

        $quantidade = 5;

        $pagina = (isset($_GET['pagina']))?(int)$_GET['pagina']:1;

        $inicio = ($quantidade * $pagina) - $quantidade;

        //pag 1. 2. 3.

        $txt_pesquisa = (isset($_POST["txt_pesquisa"]))?$_POST["txt_pesquisa"]:"";

        $sql = "SELECT id, upper(Nome) AS Nome, lower(Email) AS Email, upper(Funcao) AS Funcao FROM usuarios";

          $sql = "SELECT * FROM usuarios WHERE id= '{$txt_pesquisa}' or Nome LIKE '%{$txt_pesquisa}%' ORDER BY id LIMIT $inicio, $quantidade";

          $rs = mysqli_query($conexao,$sql) or die("Erro ao execultar a consulta. " . mysqli_error($conexao));
          while($dados = mysqli_fetch_assoc($rs)) {

         
            ?>
        <tr>
        <td class="text-nowrap"> <?=$dados["id"]?> </td>
        <td class="text-nowrap"> <?=$dados["Nome"]?> </td>
        <td class="text-nowrap"> <?=$dados["Email"]?> </d>
        <td class="text-nowrap"> <?=$dados["Funcao"]?></td>
        <td class="text-center"> <a href="index.php?menuop=edit-user&id=<?=$dados["id"] ?> "?><i class="bi bi-gear bi center"></i></a></td>
        <td class="text-center"> <a href="index.php?menuop=delete-user&id=<?=$dados["id"] ?> "?><i class="bi bi-trash"></i></a></td>
        </tr>

        <?php
          }
          ?>
    </tbody>

</table>
</div>

<ul class="pagination justify-content-center">

<?php

$sqlTotal = "SELECT id FROM usuarios ";

$qrTotal = mysqli_query($conexao,$sqlTotal) or die(mysqli_error($conexao)); //aqui é uma tabela /caso dê erro ela informa por essa condição 

$numTotal = mysqli_num_rows($qrTotal); //consulta da registro

$totalPagina = ceil($numTotal/$quantidade); //foi colocado dentro dessa função pelo fato de arredondar a paginação

echo " <li class='page-item'><span class='page-link'>Total de registros: $numTotal </span></li>";

echo '<li class="page-item"><a class="page-link" href="?menuop=user&pagina=1"> Primeira pagina </li></a>'; 

if($pagina>1){
    ?>
        <li class="page-item"><a class="page-link" href="?menuop=user&pagina=<?php echo $pagina-2?>"> << </a></li> 
    <?php
}


//validação de pagina

for($i=1;$i<=$totalPagina;$i++){
    
    if($i==$pagina){
        echo "<li class='page-item active'><span class='page-link'>$i</span></li>";
    }else{
        echo "<li class='page-item'><a class='page-link' href=\"?menuop=user&pagina=$i\">$i</a></li> ";
    }
}

if($pagina<($totalPagina-1)){
    ?>
        <li class="page-item"><a class="page-link" href="?menuop=user&pagina=<?php echo $pagina +2?>"> >> </a></li> 
    <?php
}



echo "<li class='page-item'><a class='page-link' href=\"?menuop=user&pagina=$totalPagina\">Ultima pagina</a></li>"; 

?>
</ul>