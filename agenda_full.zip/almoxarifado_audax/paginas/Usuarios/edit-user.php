<?php

$id = $_GET["id"];



$sql = "SELECT * FROM usuarios WHERE id= {$id}";

$rs = mysqli_query($conexao,$sql) or die("Erro ao recuperar os dados! " . mysqli_error($conexao));

$dados = mysqli_fetch_assoc($rs)

?>



<header>
    <h3>Editar Usuário</h3>
</header>


<div>
    <form action="index.php?menuop=update-user" method="post">

    <div>
        <label for="id"> Id </label>
        <input type="text" name="Id" value="<?=$dados["id"]?>">
    </div>

    <div>
        <label for="nome">Usuario</label>
        <input type="text" name="Nome" value="<?=$dados["Nome"]?>">
    </div>

    <div>
        <label for="email">E-mail</label>
        <input type="email" name="Email" value="<?=$dados["Email"]?>">
    </div>

    <div>
        <label for="funcao">Função</label>
        <input type="text" name="Funcao" value="<?=$dados["Funcao"]?>">
    </div>

        <div>
        <input type="submit" value="Atualizar" name="btnAtualizar">
        </div>

    </form>
</div>