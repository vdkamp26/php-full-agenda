<?php

//Constante para conexãop com o database

define("SERVIDOR","localhost");
define("USER","root");
define("SENHA","");
define("BANCO","almoxarifado_audax");

?>